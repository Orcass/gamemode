# **__Kota Kito Roleplay__**
SA-MP (San Andreas Multiplayer)

AYO AJAK TEMAN-TEMAN KAMU UNTUK BEROLEPLAY BERSAMA KAMI DI Kota Kito Roleplay PASTINYA AKAN SANGAT SERU DAN MENARIK KARENA FITUR DAN EVENT-EVENT YANG ADA DI SERVER INI, AYO TUNGGU APA LAGI JOIN SEKARANG!!!

**About Server (Feature):**
```js
[•] UCP System
[•] Staterpack (1.000 Duit IC)
[•] Dollar System 
[•] Inventory (Backpack)
[•] VIP and Gold
[•] Rob Bank, ATM, Business And Rob Ammo
[•] Neon 
[•] Speed Cam
[•] Workshop
[•] Blackmarket
[•] Anti Cheat detected
[•] Character Story on stats
[•] Good Mapping on Interior and Exterior
[•] Faction (SAPD, MEKANIK, SAMD, PEDAGANG) 
[•] Family System
[•] Terdapat Actor, ATM, Garkot hingga Vending Machine
[•] Spike, Ticket System, Barrage, Flare and Tazer ( MDC Coming Soon ) for SAPD 
[•] Insurance and Sparepart for fixed vehicle if broken
[•] BPJS and Treatment
[•] SKCK and Sistem SIM
[•] Vehicle with Plate
[•] Boombox
[•] Modshop (add Stikertext, add Bodypart, etc)
[•] Bisa judi bersama teman
[•] Bermain Basket 
```
Dan masih banyak lagi fitur-fitur menarik lainnya yang sangat seru!!

**Jobs :**
```re
[•] Petani 
[•] Supir bus
[•] Pemotong Ayam
[•] Pemeras susu
[•] Penjahit 
[•] Penambang
[•] Kargo
```
> 
> COME ON JOIN WITH US!!!
> BURUAN JOIN SEKARANG KARENA BAKALAN ADA EVENT-EVENT MENARIK LAINNYA, DAN MASIH BANYAK LAGI!!!
> 
> List Review Youtuber :
> https://youtu.be/7OgZblK1QgE
> https://www.youtube.com/watch?v=3U8WUbGSXI4
> https://youtu.be/NlHuUFQPfIE
> 
> Discord Link :
> https://discord.gg/cfdC84dAQx